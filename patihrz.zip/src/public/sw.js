// public/sw.js (atau src/public/sw.js tergantung konfigurasi Vite Anda)

const CACHE_NAME = 'dicoding-story-app-cache-v1';
const URLS_TO_CACHE = [
  '/', // Halaman utama (index.html)
  '/index.html', // Pastikan ini juga dicache jika start_url Anda adalah /
  '/manifest.webmanifest', // Manifest PWA
  // Path ke file CSS utama Anda (sesuaikan jika berbeda)
  // Jika Vite menghasilkan hash pada nama file CSS/JS di build, strategi caching mungkin perlu lebih canggih
  // atau Anda perlu menggunakan plugin PWA Vite yang menangani ini.
  // Untuk pengembangan awal, kita bisa cache path tanpa hash.
  '/src/styles/styles.css', // Sesuaikan dengan path CSS Anda
  // Path ke file JS utama Anda (sesuaikan jika berbeda)
  '/src/scripts/app.js', // Sesuaikan dengan path JS utama Anda
  // Tambahkan path ke ikon jika Anda memutuskan untuk menggunakannya nanti
  // '/icons/icon-192x192.png',
  // '/icons/icon-512x512.png',
  // Tambahkan aset penting lainnya yang ingin Anda cache untuk offline
  // Misalnya, font jika di-host sendiri, atau gambar logo
  '/vite.svg' // Contoh jika Anda menggunakan vite.svg sebagai logo
];

// Event listener untuk instalasi service worker
self.addEventListener('install', (event) => {
  console.log('Service Worker: Menginstal...');
  // Menunggu hingga proses caching selesai sebelum instalasi dianggap berhasil
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Cache dibuka, menambahkan URL inti ke cache:', URLS_TO_CACHE);
        return cache.addAll(URLS_TO_CACHE);
      })
      .then(() => {
        console.log('Service Worker: Semua URL inti berhasil dicache.');
        // Memaksa service worker yang menunggu untuk menjadi aktif
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('Service Worker: Gagal melakukan precaching saat instalasi:', error);
      })
  );
});

// Event listener untuk aktivasi service worker
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Mengaktifkan...');
  // Menghapus cache lama yang tidak sesuai dengan CACHE_NAME saat ini
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Service Worker: Menghapus cache lama:', cacheName);
            return caches.delete(cacheName);
          }
          return null; // Tidak melakukan apa-apa jika nama cache sama
        })
      );
    }).then(() => {
      console.log('Service Worker: Cache lama berhasil dihapus.');
      // Mengambil kontrol atas klien (halaman) yang tidak terkontrol
      return self.clients.claim();
    })
  );
});

// Event listener untuk permintaan fetch (mengambil aset)
self.addEventListener('fetch', (event) => {
  // Hanya tangani permintaan GET
  if (event.request.method !== 'GET') {
    return;
  }

  // Strategi Cache First untuk URL yang ada di URLS_TO_CACHE
  // Untuk URL lain, coba jaringan dulu, lalu fallback ke cache jika ada, atau gagal jika tidak ada keduanya.
  // Ini adalah contoh sederhana, strategi bisa lebih kompleks.

  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        // Jika respons ditemukan di cache, kembalikan dari cache
        if (cachedResponse) {
          console.log('Service Worker: Mengambil dari cache:', event.request.url);
          return cachedResponse;
        }

        // Jika tidak ada di cache, coba ambil dari jaringan
        console.log('Service Worker: Mencoba mengambil dari jaringan:', event.request.url);
        return fetch(event.request).then(
          (networkResponse) => {
            // Jika berhasil diambil dari jaringan, kita bisa (opsional) menyimpannya ke cache
            // untuk penggunaan selanjutnya, terutama untuk aset yang tidak ada di URLS_TO_CACHE awal.
            // Namun, berhati-hati agar tidak meng-cache semua hal secara membabi buta.
            // Untuk contoh ini, kita hanya akan mengembalikan respons jaringan tanpa caching dinamis.
            // Jika Anda ingin caching dinamis:
            /*
            if (networkResponse && networkResponse.status === 200) {
              const cache = await caches.open(CACHE_NAME);
              console.log('Service Worker: Caching new resource:', event.request.url);
              cache.put(event.request, networkResponse.clone());
            }
            */
            return networkResponse;
          }
        ).catch((error) => {
          // Jika jaringan gagal dan tidak ada di cache, ini akan menjadi error jaringan standar
          console.error('Service Worker: Gagal mengambil dari jaringan dan tidak ada di cache:', event.request.url, error);
          // Anda bisa mengembalikan halaman offline default di sini jika ada
          // return caches.match('/offline.html');
        });
      })
  );
});
