// src/scripts/routes/routes.js

// Impor modul halaman Anda
import LoginPage from '../pages/login/login-page.js';
import RegisterPage from '../pages/register/register-page.js';
import HomePage from '../pages/home/home-page.js'; // Akan ditambahkan nanti
import AddStoryPage from '../pages/add-story/add-story-page.js';
import AboutPage from '../pages/about/about-page.js';

const routes = {
  '#login': LoginPage,
  '#register': RegisterPage,
  '#home': HomePage, // Akan diaktifkan nanti
  '#add-story': AddStoryPage,
  '#about': AboutPage,
  // '/': HomePage, // Rute default bisa ke home jika sudah login, atau ke login jika belum
};

export default routes;
