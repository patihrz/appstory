// src/scripts/routes/url-parser.js
const UrlParser = {
  parseActiveUrlWithCombiner() {
    const activeUrl = window.location.hash.slice(1).toLowerCase();
    // Untuk saat ini, kita hanya mengembalikan hash apa adanya.
    // Jika Anda memiliki rute dengan parameter seperti /detail/:id,
    // Anda perlu logika tambahan di sini untuk mem-parse resource, id, dan verb.
    // Untuk Dicoding Story App, rute detailnya adalah /stories/:id,
    // jadi hash-nya bisa #stories/story-id.
    // Untuk kesederhanaan awal, kita akan menangani rute sederhana dulu.
    // Dan untuk Dicoding, hash akan langsung menjadi nama rute seperti #login, #register.
    return activeUrl ? `#${activeUrl}` : '#login'; // Default ke #login jika hash kosong
  },

  parseActiveUrlWithoutCombiner() {
    const activeUrl = window.location.hash.slice(1).toLowerCase();
    // Ini akan memecah URL menjadi bagian-bagian jika diperlukan nanti.
    // Contoh: /resource/:id/verb -> { resource: 'resource', id: ':id', verb: 'verb' }
    // Untuk sekarang, kita belum butuh ini untuk rute dasar.
    return {
      resource: activeUrl || null, // Atau null jika tidak ada
      id: null, // Akan diisi jika ada ID
      verb: null, // Akan diisi jika ada verb
    };
  },
};

export default UrlParser;
