// src/scripts/index.js (Diasumsikan ini adalah entry point utama Anda)

// CSS imports
// Pastikan path ini benar relatif terhadap index.js
// Jika index.js ada di src/scripts/ dan styles.css ada di src/styles/
import '../styles/styles.css';

// Impor objek 'app' dari app.js
// Path disesuaikan: jika index.js ada di src/scripts/ dan app.js ada di src/scripts/pages/
import appInstance from './pages/app.js';

document.addEventListener('DOMContentLoaded', async () => {
  console.log('index.js: DOMContentLoaded terdeteksi.');

  // Inisialisasi objek app dengan selector konten yang Anda inginkan
  // Tidak menggunakan 'new' karena appInstance adalah objek
  await appInstance.init({
    contentSelector: '#main-content', // Menggunakan #main-content sesuai kode Anda
  });
  console.log('index.js: appInstance.init() selesai.');

  // Panggil renderPage() untuk memuat halaman awal berdasarkan hash saat ini
  await appInstance.renderPage();
  console.log('index.js: renderPage() awal selesai.');

  // Event listener untuk hashchange tetap di sini untuk memanggil renderPage dari appInstance
  // Namun, app.js juga memiliki listener hashchange internal.
  // Untuk menghindari pemanggilan ganda atau konflik, lebih baik biarkan app.js menangani hashchange internalnya.
  // Listener hashchange di app.js akan secara otomatis memanggil appInstance.renderPage().
  // Jadi, listener di bawah ini mungkin tidak diperlukan jika app.js sudah menanganinya.
  // Jika Anda ingin kontrol eksplisit dari index.js, pastikan tidak ada duplikasi.
  // Untuk saat ini, kita akan mengandalkan listener di app.js.
  /*
  window.addEventListener('hashchange', async () => {
    console.log('index.js: Event hashchange terdeteksi. Memanggil appInstance.renderPage().');
    await appInstance.renderPage();
  });
  */

  // Logika untuk drawer Anda bisa tetap di sini
  const drawerButton = document.querySelector('#drawer-button');
  const navigationDrawer = document.querySelector('#navigation-drawer');

    if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/public/sw.js') // Path ke file sw.js Anda
      .then((registration) => {
        console.log('Service Worker: Registrasi berhasil, scope:', registration.scope);
      })
      .catch((error) => {
        console.error('Service Worker: Registrasi gagal:', error);
      });
  });
} else {
  console.log('Service Worker tidak didukung oleh browser ini.');
}

  if (drawerButton && navigationDrawer) {
    console.log('index.js: Elemen drawer ditemukan.');
    drawerButton.addEventListener('click', (event) => {
      event.stopPropagation();
      navigationDrawer.classList.toggle('open');
      console.log('index.js: Tombol drawer diklik, status drawer:', navigationDrawer.classList.contains('open'));
    });

    // Menutup drawer jika diklik di luar area drawer (opsional)
    document.body.addEventListener('click', (event) => {
      if (navigationDrawer.classList.contains('open') && !navigationDrawer.contains(event.target) && event.target !== drawerButton) {
        navigationDrawer.classList.remove('open');
        console.log('index.js: Klik di luar drawer, drawer ditutup.');
      }
    });
  } else {
    console.warn('index.js: Tombol drawer (#drawer-button) atau panel navigasi (#navigation-drawer) tidak ditemukan.');
  }

  console.log('index.js: Inisialisasi selesai.');
});
