// src/scripts/data/api.js

const BASE_URL = 'https://story-api.dicoding.dev/v1';

// Fungsi loginUser yang sudah ada
const loginUser = async (email, password) => {
  try {
    const response = await fetch(`${BASE_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });
    const responseJson = await response.json();
    console.log('API Response (loginUser):', responseJson);
    return responseJson;
  } catch (error) {
    console.error('Error during login API call:', error);
    return {
      error: true,
      message: 'Login failed due to a network or server error. Please check your connection and try again.',
    };
  }
};

// Fungsi registerUser yang sudah ada
const registerUser = async (name, email, password) => {
  try {
    const response = await fetch(`${BASE_URL}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, email, password }),
    });
    const responseJson = await response.json();
    console.log('API Response (registerUser):', responseJson);
    return responseJson;
  } catch (error) {
    console.error('Error during registration API call:', error);
    return {
      error: true,
      message: 'Registration failed due to a network or server error. Please check your connection and try again.',
    };
  }
};

/**
 * Mengambil semua cerita dari API.
 * Memerlukan token autentikasi.
 * @param {string} token - Token JWT untuk autentikasi.
 * @param {object} [params] - Parameter query opsional.
 * @param {number} [params.page] - Nomor halaman.
 * @param {number} [params.size] - Jumlah item per halaman.
 * @param {0|1} [params.location] - 1 untuk cerita dengan lokasi, 0 untuk semua (default 0).
 * @returns {Promise<Object>} Promise yang resolve dengan respons JSON dari API.
 */
const getAllStories = async (token, params = {}) => {
  if (!token) {
    console.error('getAllStories: Token is required.');
    return {
      error: true,
      message: 'Authentication token is missing. Please login again.',
    };
  }

  // Membangun query string dari parameter
  const queryParams = new URLSearchParams();
  if (params.page) queryParams.append('page', params.page);
  if (params.size) queryParams.append('size', params.size);
  // API default ke 0 jika parameter lokasi tidak ada atau tidak valid, jadi kita hanya mengirim jika ada nilainya.
  if (params.location !== undefined && (params.location === 0 || params.location === 1)) {
    queryParams.append('location', params.location);
  }

  const queryString = queryParams.toString();
  const requestUrl = `${BASE_URL}/stories${queryString ? `?${queryString}` : ''}`;
  console.log('getAllStories: Requesting URL:', requestUrl);

  try {
    const response = await fetch(requestUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    const responseJson = await response.json();
    console.log('API Response (getAllStories):', responseJson);
    return responseJson;
  } catch (error) {
    console.error('Error during getAllStories API call:', error);
    return {
      error: true,
      message: 'Failed to fetch stories due to a network or server error. Please check your connection and try again.',
    };
  }
};

/**
 * Menambahkan cerita baru ke API.
 * Memerlukan token autentikasi.
 * @param {string} token - Token JWT untuk autentikasi.
 * @param {FormData} formData - Data form yang berisi description, photo, dan opsional lat/lon.
 * @returns {Promise<Object>} Promise yang resolve dengan respons JSON dari API.
 */
const addNewStory = async (token, formData) => {
  if (!token) {
    console.error('addNewStory: Token is required.');
    return {
      error: true,
      message: 'Authentication token is missing. Please login again.',
    };
  }

  // Validasi dasar untuk FormData
  if (!formData.has('description') || !formData.has('photo')) {
    console.error('addNewStory: Description and photo are required in FormData.');
    return {
      error: true,
      message: 'Deskripsi dan foto wajib diisi.',
    };
  }
  console.log('addNewStory: Mengirim data cerita baru...');

  try {
    const response = await fetch(`${BASE_URL}/stories`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        // Content-Type TIDAK perlu di-set secara eksplisit untuk FormData,
        // browser akan menanganinya secara otomatis termasuk boundary.
      },
      body: formData,
    });
    const responseJson = await response.json();
    console.log('API Response (addNewStory):', responseJson);
    return responseJson;
  } catch (error) {
    console.error('Error during addNewStory API call:', error);
    return {
      error: true,
      message: 'Failed to add new story due to a network or server error. Please check your connection and try again.',
    };
  }
};

// Ekspor semua fungsi yang akan digunakan oleh modul lain
export { loginUser, registerUser, getAllStories, addNewStory };