// src/scripts/pages/home/home-page.js

import { getAllStories } from '../../data/api.js';
import { getAuthToken, getUserName, clearUserSession } from '../../data/authService.js';

const HomePage = {
  mapsRendered: {}, // Untuk melacak peta yang sudah dirender
  storyMapInstances: {}, // Untuk menyimpan instance peta Leaflet per cerita

  async render() {
    const userName = getUserName();
    return `
      <div class="container home-container py-4">
        <header class="home-header mb-4">
          <h1 id="welcomeMessage" class="home-title">Selamat Datang, ${userName || 'Pengguna'}!</h1>
          <button id="logoutButton" class="btn btn-outline-danger btn-sm">
            <i class="fas fa-sign-out-alt"></i> Logout
          </button>
        </header>
        <p class="text-center lead mb-4">Jelajahi cerita-cerita terbaru dari komunitas Dicoding.</p>
        <div id="storiesList" class="stories-list">
          <div class="loading-spinner text-center my-5">
            <div class="spinner-border text-primary" role="status">
              <span class="visually-hidden">Memuat cerita...</span>
            </div>
            <p class="mt-2">Memuat cerita...</p>
          </div>
          </div>
        <div class="add-story-fab-container">
          <a href="#add-story" class="add-story-fab shadow" aria-label="Tambah Cerita Baru" title="Tambah Cerita Baru">
            <i class="fas fa-plus"></i>
          </a>
        </div>
      </div>
    `;
  },

  async afterRender() {
    console.log('HomePage afterRender: Menjalankan afterRender...');
    const storiesListElement = document.getElementById('storiesList');
    const logoutButton = document.getElementById('logoutButton');
    const welcomeMessageElement = document.getElementById('welcomeMessage');
    
    // Reset peta yang sudah dirender dan instance peta setiap kali halaman dimuat ulang
    this.beforeUnload(); // Panggil beforeUnload untuk membersihkan peta lama sebelum render baru

    const currentUserName = getUserName();
    if (welcomeMessageElement && currentUserName) {
        welcomeMessageElement.textContent = `Selamat Datang, ${currentUserName}!`;
    }

    if (logoutButton) {
      logoutButton.addEventListener('click', () => {
        clearUserSession();
        window.location.hash = '#login';
      });
    }

    const token = getAuthToken();
    if (!token) {
      if (storiesListElement) storiesListElement.innerHTML = '<p class="alert alert-warning text-center">Anda harus login untuk melihat cerita. Mengarahkan ke halaman login...</p>';
      setTimeout(() => {
        if (window.location.hash !== '#login') window.location.hash = '#login';
      }, 1500);
      return;
    }

    try {
      const result = await getAllStories(token, { size: 12, page: 1, location: 0 }); // Ambil lebih banyak cerita
      console.log('HomePage afterRender: Data cerita diterima:', result);

      if (storiesListElement) {
        if (result.error) {
          storiesListElement.innerHTML = `<p class="alert alert-danger text-center">Gagal memuat cerita: ${result.message}</p>`;
        } else if (result.listStory && result.listStory.length > 0) {
          storiesListElement.innerHTML = result.listStory.map(story => this.renderStoryItem(story)).join('');
          result.listStory.forEach(story => {
            if (story.lat && story.lon) {
              // Beri sedikit waktu agar elemen peta ada di DOM
              setTimeout(() => this.initStoryMap(story), 0);
            }
          });
        } else {
          storiesListElement.innerHTML = '<p class="text-center text-muted mt-5">Belum ada cerita untuk ditampilkan. Jadilah yang pertama!</p>';
        }
      }
    } catch (error) {
      console.error('HomePage afterRender: Error saat mengambil atau merender cerita:', error);
      if (storiesListElement) storiesListElement.innerHTML = '<p class="alert alert-danger text-center">Terjadi kesalahan saat memuat cerita. Coba muat ulang halaman.</p>';
    }
  },

  renderStoryItem(story) {
    const mapPlaceholderId = `map-${story.id}`;
    const hasLocation = story.lat && story.lon;
    const mapHtml = hasLocation ? 
      `<div id="${mapPlaceholderId}" class="story-map mt-3" style="height: 180px; width: 100%; border-radius: 0.25rem;"></div>` : 
      '';

    // Format tanggal yang lebih ringkas
    const storyDate = new Date(story.createdAt).toLocaleDateString('id-ID', {
      day: 'numeric', month: 'short', year: 'numeric'
    });

    return `
      <article class="story-item card h-100 shadow-sm">
        <figure class="story-image-figure mb-0">
        <img 
          src="${story.photoUrl}" 
          alt="Cerita oleh ${story.name}: ${this.truncateDescription(story.description, 50)}" 
          class="story-image card-img-top" 
          onerror="this.onerror=null;this.src='...';this.alt='Gambar tidak dapat dimuat';"
          loading="lazy">
        </figure>
        <div class="story-content card-body d-flex flex-column">
          <h3 class="story-name card-title h5 mb-2">${story.name || 'Pengguna Anonim'}</h3>
          <p class="story-description card-text text-secondary small mb-3 flex-grow-1">
            ${this.truncateDescription(story.description || 'Tidak ada deskripsi.', 100)}
          </p>
          ${mapHtml}
          <p class="story-date card-text mt-auto pt-2 border-top">
            <small class="text-muted">
              <i class="fas fa-calendar-alt me-1"></i> ${storyDate}
            </small>
          </p>
        </div>
      </article>
    `;
  },

  initStoryMap(story) {
    const mapId = `map-${story.id}`;
    const mapElement = document.getElementById(mapId);

    if (this.storyMapInstances[mapId] || !mapElement) {
      return;
    }

    try {
      console.log(`HomePage initStoryMap: Menginisialisasi peta untuk story ID ${story.id} di elemen ${mapId}`);
      const storyCoords = [parseFloat(story.lat), parseFloat(story.lon)];
      
      // Periksa apakah koordinat valid
      if (isNaN(storyCoords[0]) || isNaN(storyCoords[1])) {
          console.error(`Koordinat tidak valid untuk story ID ${story.id}: Lat=${story.lat}, Lon=${story.lon}`);
          if (mapElement) mapElement.innerHTML = '<p class="text-muted text-center small">Data lokasi tidak valid.</p>';
          return;
      }

      const map = L.map(mapId, {
          scrollWheelZoom: false,
          dragging: true, // Aktifkan dragging agar pengguna bisa menggeser peta
          tap: true,
          zoomControl: false, // Sembunyikan kontrol zoom default jika peta kecil
      }).setView(storyCoords, 14); // Zoom sedikit lebih jauh untuk konteks

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager_labels_under/{z}/{x}/{y}{r}.png', { // Tile layer yang lebih modern
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19
      }).addTo(map);
      
      // Tambahkan kontrol zoom kustom jika diinginkan atau biarkan default jika zoomControl: true
      // L.control.zoom({ position: 'topright' }).addTo(map);


      L.marker(storyCoords, {
          icon: L.icon({ // Ikon kustom untuk marker
              iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
              shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
              iconSize: [25, 41],
              iconAnchor: [12, 41],
              popupAnchor: [1, -34],
              shadowSize: [41, 41]
          })
      }).addTo(map)
        .bindPopup(`<b>${story.name || 'Cerita'}</b><br><small>${this.truncateDescription(story.description || 'Lokasi cerita.', 40)}</small>`)
        .openPopup();

      this.storyMapInstances[mapId] = map; // Simpan instance peta
      this.mapsRendered[mapId] = true;
      console.log(`Peta untuk ${mapId} berhasil diinisialisasi.`);
    } catch (error) {
        console.error(`Gagal menginisialisasi peta untuk story ID ${story.id}:`, error);
        if (mapElement) {
            mapElement.innerHTML = '<p class="text-muted text-center small">Peta tidak dapat dimuat.</p>';
        }
    }
  },

  truncateDescription(description, maxLength = 150) {
    if (typeof description !== 'string') return '';
    if (description.length > maxLength) {
      return `${description.substring(0, maxLength)}...`;
    }
    return description;
  },

  async beforeUnload() {
    console.log('HomePage beforeUnload: Membersihkan peta...');
    Object.keys(this.storyMapInstances).forEach(mapId => {
      const mapInstance = this.storyMapInstances[mapId];
      if (mapInstance) {
        mapInstance.remove(); // Hapus instance peta Leaflet
        console.log(`Peta dengan ID ${mapId} telah dihapus.`);
      }
    });
    this.storyMapInstances = {}; // Reset objek instance
    this.mapsRendered = {}; // Reset peta yang dirender
  }
};

export default HomePage;