// src/scripts/app.js
// Diasumsikan file ini sekarang berada di src/scripts/pages/app.js
// atau di src/scripts/app.js jika itu adalah entry point utama Anda.
// Pastikan path impor di bawah ini sesuai dengan lokasi aktual app.js

// Path disesuaikan untuk naik satu level dari 'pages' ke 'scripts', lalu ke 'routes'
// Jika app.js ada di src/scripts/app.js, maka pathnya menjadi './routes/routes.js'
import routes from '../routes/routes.js'; // Sesuaikan path ini jika app.js ada di src/scripts/
import UrlParser from '../routes/url-parser.js'; // Sesuaikan path ini jika app.js ada di src/scripts/

const app = {
  /**
   * Metode inisialisasi aplikasi.
   * Mengatur elemen konten utama dan event listener untuk navigasi.
   */
  async init() {
    console.log('Menginisialisasi aplikasi...');
    // Dapatkan elemen kontainer utama dari index.html
    // Pastikan ID ini ('app-root') atau tag <main> ada di index.html Anda
    this.content = document.getElementById('app-root') || document.querySelector('main');

    if (!this.content) {
      console.error("Kritis: Elemen konten utama ('app-root' atau 'main') tidak ditemukan dalam DOM!");
      document.body.innerHTML = '<p style="color: red; text-align: center; margin-top: 50px;">Error Kritis: Kontainer aplikasi tidak ditemukan. Periksa struktur HTML Anda.</p>';
      return;
    }
    console.log('Elemen konten utama ditemukan:', this.content);

    window.addEventListener('hashchange', () => {
      console.log('Event hashchange terdeteksi. Hash baru:', window.location.hash);
      this.renderPage();
    });

    window.addEventListener('load', () => {
      console.log('Event load terdeteksi. Hash saat ini:', window.location.hash);
      if (!window.location.hash) {
        console.log('Tidak ada hash pada URL. Mengarahkan ke #login...');
        window.location.hash = '#login';
      } else {
        this.renderPage();
      }
    });
  },

  /**
   * Metode untuk merender halaman berdasarkan URL hash saat ini.
   * Menangani logika routing dan pemanggilan metode render dari modul halaman.
   */
  async renderPage() {
    if (!this.content) {
      console.error("renderPage dipanggil tetapi elemen konten utama (this.content) tidak terdefinisi.");
      return;
    }

    const url = UrlParser.parseActiveUrlWithCombiner();
    console.log(`renderPage: URL yang diparsing adalah "${url}"`);

    // Daftar rute yang tidak memerlukan login
    // Perhatikan: '#home' juga ada di sini. Jika '#home' seharusnya diproteksi, hapus dari array ini.
    const publicRoutes = ['#login', '#register', '#about', '#home']; 
    const token = localStorage.getItem('authToken');
    console.log(`renderPage: Token ditemukan di localStorage: ${token ? 'Ya' : 'Tidak'}`);

    // Jika mencoba mengakses rute non-publik (yang tidak ada di publicRoutes) tanpa token, arahkan ke login
    if (!publicRoutes.includes(url) && !token) {
      console.warn(`Akses ke rute terproteksi "${url}" ditolak (tidak ada token). Mengarahkan ke #login.`);
      window.location.hash = '#login';
      return; 
    }

    // Jika sudah login dan mencoba akses halaman login/register, arahkan ke home (opsional)
    if (token && (url === '#login' || url === '#register')) { // Tidak perlu publicRoutes.includes(url) di sini
      if (window.location.hash !== '#home') { // Hanya redirect jika belum di #home
        console.log(`Pengguna sudah login dan mencoba akses "${url}". Mengarahkan ke #home.`);
        window.location.hash = '#home';
        return; 
      }
    }

    let pageModule = routes[url];

    if (!pageModule) {
      console.warn(`Rute "${url}" tidak ditemukan secara eksplisit di routes.js.`);
      // Jika pengguna sudah login dan rute #home tidak ditemukan secara eksplisit, ini bisa jadi error konfigurasi.
      // Namun, karena #home ada di publicRoutes, logika di atas tidak akan menganggapnya terproteksi.
      // Jika #home dihapus dari publicRoutes, maka logika proteksi akan berlaku.
      // Untuk sekarang, jika rute tidak ada, default ke login.
      console.log(`Rute "${url}" tidak ditemukan. Menggunakan fallback ke modul #login.`);
      pageModule = routes['#login'];
    }
    
    console.log(`renderPage: Modul halaman yang dipilih untuk "${url}":`, pageModule ? pageModule : 'Tidak ada (fallback ke #login mungkin terjadi atau error jika #login juga tidak ada)');

    if (pageModule && typeof pageModule.render === 'function') {
      console.log(`renderPage: Merender modul halaman untuk "${url}"...`);
      try {
        this.content.innerHTML = await pageModule.render();
        console.log(`renderPage: Konten HTML untuk "${url}" berhasil dirender.`);

        if (typeof pageModule.afterRender === 'function') {
          console.log(`renderPage: Menjalankan afterRender untuk "${url}"...`);
          await pageModule.afterRender();
          console.log(`renderPage: afterRender untuk "${url}" selesai.`);
        }
      } catch (error) {
        console.error(`Error saat merender halaman untuk rute "${url}":`, error);
        this.content.innerHTML = `<p style="color: red;">Terjadi kesalahan saat memuat halaman "${url}". Silakan coba lagi atau hubungi administrator.</p>`;
      }
    } else {
      console.warn(`Modul halaman untuk rute "${url}" (atau fallbacknya) tidak ditemukan atau tidak memiliki metode render. Menampilkan halaman 404 generik.`);
      this.content.innerHTML = `<p>Halaman untuk rute <strong>${url}</strong> tidak ditemukan (404). Mungkin Anda bisa kembali ke <a href="#login">halaman login</a>?</p>`;
    }
  },
};

document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM sepenuhnya dimuat dan diparsing. Menginisialisasi app...');
  app.init();
});

export default app;
